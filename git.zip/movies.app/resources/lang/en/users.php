<?php

return [
    'users' => 'Users',
    'user' => 'User',
    'name' => 'Name',
    'email' => 'Email',
    'image' => 'Image',
    'old_password' => 'Old password',
    'password' => 'Password',
    'password_confirmation' => 'Password confirmation',
    'profile' => 'Profile',
    'change_data' => 'Change data',
    'change_password' => 'Change password',
    'edit_profile' => 'Edit profile',
    'incorrect_old_password' => 'Incorrect old password',

];