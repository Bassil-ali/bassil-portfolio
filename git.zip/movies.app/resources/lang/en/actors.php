<?php

return [
    'actors' => 'Actors',
    'actor' => 'Actor',
    'name' => 'Name',
    'image' => 'Image',
    'movies_count' => 'Movies count',
    'related_movies' => 'Related movies',
];