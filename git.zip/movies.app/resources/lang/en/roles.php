<?php

return [
    'roles' => 'Roles',
    'role' => 'Role',
    'name' => 'Name',
    'permissions' => 'Permissions',
    'model' => 'Model',
    'admins_count' => 'Admins count',
];