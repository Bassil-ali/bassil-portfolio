<?php

return [
    'notifications' => 'Notifications',
    'notification' => 'Notification',
    'text' => 'Text',
];