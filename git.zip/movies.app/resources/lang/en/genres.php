<?php

return [
    'genres' => 'Genres',
    'genre' => 'Genre',
    'name' => 'Name',
    'movies_count' => 'Movies count',
    'related_movies' => 'Related movies',
];