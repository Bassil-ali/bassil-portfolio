<?php

return [
    'roles' => 'الادوار',
    'role' => 'الدور',
    'name' => 'الاسم',
    'permissions' => 'التصريحات',
    'model' => 'نموذج',
    'admins_count' => 'عدد الادمن',
];