<a href="{{ route('admin.movies.show', $movie->id) }}">
    <img src="{{ $movie->poster_path }}" style="width: 100px;" alt="">
</a>